Para el dia `= date(now)`
Tenemos:
Peso específico, $y = peso/volumen$
Densidad relativa, y tablas de densidades 
$df = PdA$ en forma diferencial 

Presión manómetrica
Fuerza promedio que ejerce el liquido sobre una pared:
$dF = pdA$
$dF = (pdh)(Ldh)$
$F = pgL \int_0^H h dh$

Preguntas adicionales, empuje experimentado y la presión en la cara superior del bloque (ultimo ejercicio)

Hidrodinámica: supuestos de un líquido ideal, y como funcionan los liquidos fluyendo por tubos con paredes ideales, liquidos no viscosos, flujos estables, el medidor de Venturi

Las rosas de los pétalos en funciones trigonometricas, $r = A cos (n theta)$
A = longitud de petalo
Rosa de 2n petalos 
Volumenes en integrales 




